For this project, the Lent network has been implemented using a custom-written convolution layer, and then at the end of each convolution layer, the MaxPoling filters of each layer have been displayed using the Metplot Lib library. And based on this, the changes of the input image are displayed after the operations performed on the image in each layer.
Of course, I checked this with the convolution layer that I wrote before, now I will implement it with this new convolution layer and check it carefully and plot the output feature maps of each layer.


برای این پروژه شبکه ی لنت را با استفاده از لایه ی کانولوشنی که به صورت کاستوم نوشته شده پیاده سازی کرده و سپس در انتهای هر لایه ی کانولوشن و مکس پولینگ  فیلترهای هر لایه  با استفاده از کتابخانه ی متپلات لیب نمایش داده شده است. و براین اساس تغییرات تصویر ورودی بعد از عملیاتی که در هر لایه بر روی تصویر انجام می گیرد به نمایش گذاشته می شود.
البته این رو من با لایه کانولوشنی که قبلا نوشتم چک کردم الان با این لایه ی کانولوشن جدید پیاده ش کنم و دقیق چکش کنم و فیچر مپ های خروجی هر لایه را پلات بگیرم.
